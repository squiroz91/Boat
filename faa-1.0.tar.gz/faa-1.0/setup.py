from distutils.core import setup
setup(name='faa',
      version='1.0',
      py_modules=['faa'],
)
